import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { TOOLS } from '../constants';
import { CheckCircle2, Crown, Lock, ChevronRight, Zap } from 'lucide-react';
import { usePremium } from './PremiumContext';

const Dashboard: React.FC = () => {
  const { isPremium, usageCount, maxFreeUses } = usePremium();
  const navigate = useNavigate();

  return (
    <div className="space-y-8 md:space-y-10">
      {/* HERO SECTION - 3D Cinematic & Lighter */}
      <div className={`relative w-full rounded-3xl md:rounded-[2.5rem] overflow-hidden shadow-2xl isolate group min-h-[260px] flex flex-col justify-center transition-all duration-500 transform hover:scale-[1.01] ${isPremium ? 'bg-gradient-to-br from-slate-900 via-amber-950 to-black border border-amber-500/40 shadow-amber-900/30 ring-1 ring-amber-500/20' : 'bg-gradient-to-br from-slate-800 via-slate-900 to-slate-950 border border-slate-700/50 shadow-black/50 ring-1 ring-white/10'}`}>
         
         {/* 3D Depth Inner Shadow */}
         <div className="absolute inset-0 shadow-[inset_0_0_80px_rgba(0,0,0,0.6)] pointer-events-none rounded-[2.5rem] z-20"></div>

         {/* Animated Grid Lines Background (Lighter) */}
         <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.07)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.07)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,black_60%,transparent_100%)] animate-grid-flow pointer-events-none opacity-60"></div>
         
         {/* --- RANDOM LASER LINES --- */}
         
         {/* Laser 1: Top-Left to Bottom-Right */}
         <div className={`absolute w-[150%] h-[2px] bg-gradient-to-r from-transparent via-white to-transparent opacity-0 animate-laser-diag-1 -rotate-45 pointer-events-none blur-[2px] ${isPremium ? 'via-amber-400' : 'via-indigo-400'}`}></div>
         
         {/* Laser 2: Top-Right to Bottom-Left (Slower) */}
         <div className={`absolute w-[150%] h-[1px] bg-gradient-to-r from-transparent via-white to-transparent opacity-0 animate-laser-diag-2 rotate-45 pointer-events-none blur-[1px] delay-700 ${isPremium ? 'via-yellow-300' : 'via-purple-400'}`}></div>

         {/* Laser 3: Horizontal Scan (Classic) */}
         <div className={`absolute top-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/50 to-transparent animate-scan-laser pointer-events-none ${isPremium ? 'via-amber-400/50' : 'via-indigo-400/50'}`}></div>

         {/* Content Wrapper */}
         <div className="relative z-30 w-full p-6 md:p-10 flex flex-col gap-6">
            
            {/* Top Bar: Badge & Upgrade Button */}
            <div className="flex items-center justify-between w-full">
               <div className={`px-3 py-1 rounded-full border text-[10px] font-bold uppercase tracking-widest backdrop-blur-md flex items-center gap-2 shadow-lg ${isPremium ? 'bg-amber-950/40 border-amber-500/50 text-amber-300' : 'bg-slate-800/60 border-indigo-400/30 text-indigo-300'}`}>
                  <div className={`w-2 h-2 rounded-full ${isPremium ? 'bg-amber-400 shadow-[0_0_10px_#fbbf24]' : 'bg-indigo-400 shadow-[0_0_10px_#6366f1]'} animate-pulse`}></div>
                  {isPremium ? 'Pro Active' : 'Version 2.0'}
               </div>

               {/* Upgrade Button (Top Right) */}
               {!isPremium && (
                 <button 
                    onClick={() => navigate('/plans')}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 text-black text-xs font-black shadow-[0_0_25px_rgba(245,158,11,0.4)] hover:scale-105 active:scale-95 transition-all animate-pulse-slow border-t border-white/40"
                 >
                    <Crown size={14} fill="currentColor" />
                    <span>UPGRADE PRO</span>
                    <ChevronRight size={14} className="opacity-60" />
                 </button>
               )}
            </div>

            {/* Main Typography */}
            <div className="space-y-2 md:space-y-4 max-w-3xl">
               <h1 className={`text-5xl md:text-7xl font-black italic tracking-tighter text-transparent bg-clip-text drop-shadow-[0_10px_10px_rgba(0,0,0,0.5)] animate-text-shimmer bg-[length:200%_auto] py-2 ${isPremium ? 'bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-500' : 'bg-gradient-to-r from-white via-indigo-200 to-slate-400'}`}>
                  SONIX {isPremium ? 'PRO' : 'TOOLS'}
               </h1>
               <p className={`text-sm md:text-lg max-w-lg leading-relaxed font-semibold tracking-wide ${isPremium ? 'text-amber-100/70' : 'text-slate-300'}`}>
                  {isPremium 
                    ? "Welcome to the ultimate developer experience. All limits removed." 
                    : "Premium offline utilities with cinematic UI. Upgrade to unlock full potential."}
               </p>
            </div>

            {/* Feature Pills */}
            <div className="flex flex-wrap gap-2 md:gap-3 pt-2">
               {[isPremium ? 'Unlimited Access' : '5 Free Uses', '12 Offline Tools', isPremium ? 'Priority Support' : 'Cinematic UI'].map((feature, i) => (
                  <div key={i} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border backdrop-blur-md transition-colors group/pill cursor-default ${isPremium ? 'bg-amber-900/20 border-amber-500/20 hover:bg-amber-900/30' : 'bg-white/5 border-white/10 hover:bg-white/10'}`}>
                     <CheckCircle2 size={12} className={`${isPremium ? "text-amber-400" : "text-emerald-400"} group-hover/pill:scale-110 transition-transform`} />
                     <span className={`text-xs font-bold ${isPremium ? 'text-amber-200' : 'text-slate-300'}`}>{feature}</span>
                  </div>
               ))}
               {!isPremium && (
                   <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/20 border border-indigo-400/30 backdrop-blur-md">
                      <Zap size={12} className="text-indigo-400" />
                      <span className="text-xs font-bold text-indigo-200">Fast & Secure</span>
                   </div>
               )}
            </div>

         </div>
      </div>

      {/* Tools Grid Section */}
      <div id="tools-grid" className="scroll-mt-24">
        <h2 className="text-lg md:text-2xl font-bold text-slate-800 dark:text-slate-200 mb-6 flex items-center gap-3">
          <div className={`w-1 h-6 md:h-8 rounded-full ${isPremium ? 'bg-gradient-to-b from-amber-400 to-yellow-600' : 'bg-gradient-to-b from-indigo-500 to-purple-600'}`}></div>
          All Tools
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-6">
          {TOOLS.map((tool) => {
            const isLocked = !isPremium && usageCount >= maxFreeUses;
            return (
              <Link 
                key={tool.id} 
                to={tool.path}
                onClick={(e) => {
                   if (isLocked) {
                       e.preventDefault();
                       navigate('/plans');
                   }
                }}
                className={`group relative border p-4 md:p-5 rounded-2xl md:rounded-[1.5rem] hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden flex flex-col h-full active:scale-95 md:active:scale-100 ${isPremium ? 'bg-slate-900 border-amber-900/30 hover:shadow-amber-500/10' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:shadow-indigo-500/10 dark:hover:shadow-black/40'}`}
              >
                <div className={`w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center mb-3 md:mb-4 transition-all duration-300 shadow-inner group-hover:shadow-lg ${isPremium ? 'bg-slate-800 text-amber-500 group-hover:bg-gradient-to-br group-hover:from-amber-500 group-hover:to-yellow-600 group-hover:text-black' : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 group-hover:bg-gradient-to-br group-hover:from-indigo-500 group-hover:to-purple-600 group-hover:text-white'}`}>
                  <tool.icon size={20} className="md:w-7 md:h-7" />
                </div>
                
                <h3 className="text-sm md:text-lg font-bold text-slate-800 dark:text-slate-100 mb-1 leading-tight">
                  {tool.name}
                </h3>
                <p className="hidden md:block text-slate-500 dark:text-slate-400 text-xs md:text-sm leading-relaxed line-clamp-2 mb-auto opacity-80">
                  {tool.description}
                </p>

                {/* Status Badges */}
                {isPremium ? (
                  <span className="absolute top-3 right-3 md:top-4 md:right-4 bg-gradient-to-r from-amber-400 to-yellow-600 text-black border border-amber-300 text-[9px] md:text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-sm flex items-center gap-1">
                    PRO <Crown size={8} fill="currentColor" />
                  </span>
                ) : (
                  <div className="absolute top-3 right-3 md:top-4 md:right-4 flex flex-col items-end gap-1">
                     <span className={`text-[9px] md:text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm border ${usageCount >= maxFreeUses ? 'bg-red-500 text-white border-red-600' : 'bg-indigo-50 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 border-indigo-100 dark:border-slate-700'}`}>
                       {usageCount >= maxFreeUses ? 'LOCKED' : `${maxFreeUses - usageCount}/${maxFreeUses} Left`}
                     </span>
                  </div>
                )}
                
                {/* Lock Overlay if limit reached */}
                {isLocked && (
                    <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] flex items-center justify-center z-20">
                        <Lock size={24} className="text-white drop-shadow-lg" />
                    </div>
                )}
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;