import React, { useState } from 'react';
import { FileUp, FilePlus, Scissors, Download, FileText } from 'lucide-react';

declare const PDFLib: any;

const PdfTools: React.FC = () => {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const mergePDFs = async () => {
    if (files.length < 2) return;
    setIsProcessing(true);
    
    try {
      if (typeof PDFLib === 'undefined') {
        alert('PDF library not loaded. Please check your internet connection or local library files.');
        setIsProcessing(false);
        return;
      }

      const mergedPdf = await PDFLib.PDFDocument.create();
      
      for (const file of files) {
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await PDFLib.PDFDocument.load(arrayBuffer);
        const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
        copiedPages.forEach((page: any) => mergedPdf.addPage(page));
      }

      const pdfBytes = await mergedPdf.save();
      downloadBlob(pdfBytes, 'merged-sonix.pdf', 'application/pdf');
    } catch (error) {
      console.error(error);
      alert('Error processing PDFs');
    }
    setIsProcessing(false);
  };

  const downloadBlob = (data: Uint8Array, filename: string, mimeType: string) => {
    const blob = new Blob([data], { type: mimeType });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-3xl mx-auto animate-slide-up">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">PDF Tools</h2>
        <p className="text-slate-500 dark:text-slate-400">Merge multiple PDF files safely in your browser.</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-xl">
        <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl p-10 bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
          <input
            type="file"
            multiple
            accept="application/pdf"
            onChange={handleFileChange}
            className="hidden"
            id="pdf-upload"
          />
          <label htmlFor="pdf-upload" className="cursor-pointer flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center text-red-500 mb-4">
              <FileUp size={32} />
            </div>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200">Drop PDFs here</h3>
            <p className="text-slate-500 text-sm mt-1">or click to browse files</p>
          </label>
        </div>

        {files.length > 0 && (
          <div className="mt-8">
            <h4 className="font-semibold text-slate-700 dark:text-slate-300 mb-4">Selected Files ({files.length})</h4>
            <div className="space-y-2 mb-8">
              {files.map((file, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-100 dark:border-slate-800">
                  <FileText size={20} className="text-red-500" />
                  <span className="text-sm truncate flex-1">{file.name}</span>
                  <span className="text-xs text-slate-400">{(file.size / 1024 / 1024).toFixed(2)} MB</span>
                </div>
              ))}
            </div>

            <div className="flex gap-4">
              <button
                onClick={mergePDFs}
                disabled={isProcessing || files.length < 2}
                className="flex-1 flex items-center justify-center gap-2 py-3 bg-primary text-white rounded-xl font-bold hover:bg-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-primary/20"
              >
                {isProcessing ? (
                  <span>Processing...</span>
                ) : (
                  <>
                    <FilePlus size={20} /> Merge & Download
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PdfTools;