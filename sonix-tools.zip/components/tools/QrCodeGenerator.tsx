import React, { useState, useEffect, useRef } from 'react';
import { Download, RefreshCw, Link as LinkIcon } from 'lucide-react';

// Declaration for the global QRCode library
declare const QRCode: any;

const QrCodeGenerator: React.FC = () => {
  const [text, setText] = useState('https://example.com');
  const [size, setSize] = useState(256);
  const [colorDark, setColorDark] = useState('#000000');
  const [colorLight, setColorLight] = useState('#ffffff');
  const qrRef = useRef<HTMLDivElement>(null);

  const generateQR = () => {
    if (qrRef.current && typeof QRCode !== 'undefined') {
      qrRef.current.innerHTML = '';
      try {
        new QRCode(qrRef.current, {
          text: text,
          width: size,
          height: size,
          colorDark: colorDark,
          colorLight: colorLight,
          correctLevel: 2 // QRCode.CorrectLevel.H
        });
      } catch (e) {
        console.error("QR Generation failed", e);
      }
    }
  };

  useEffect(() => {
    // Debounce generation
    const timer = setTimeout(generateQR, 300);
    return () => clearTimeout(timer);
  }, [text, size, colorDark, colorLight]);

  const downloadQR = () => {
    const img = qrRef.current?.querySelector('img');
    if (img) {
      const link = document.createElement('a');
      link.href = img.src;
      link.download = 'qrcode.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="max-w-4xl mx-auto animate-slide-up">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">QR Code Generator</h2>
        <p className="text-slate-500 dark:text-slate-400">Create customizable QR codes instantly locally.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold mb-2">Content</label>
              <div className="relative">
                <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary/50 outline-none"
                  placeholder="Enter URL or text"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">Size: {size}px</label>
              <input
                type="range"
                min="128"
                max="512"
                step="32"
                value={size}
                onChange={(e) => setSize(parseInt(e.target.value))}
                className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-primary"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold mb-2">Foreground</label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={colorDark}
                    onChange={(e) => setColorDark(e.target.value)}
                    className="h-10 w-full rounded cursor-pointer"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Background</label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={colorLight}
                    onChange={(e) => setColorLight(e.target.value)}
                    className="h-10 w-full rounded cursor-pointer"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center bg-slate-100 dark:bg-slate-950/50 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 min-h-[400px]">
          <div 
            ref={qrRef}
            className="bg-white p-4 rounded-xl shadow-lg mb-8"
            style={{ minWidth: '150px', minHeight: '150px' }}
          >
            {/* QR Code renders here */}
          </div>
          
          <div className="flex gap-4">
            <button
              onClick={generateQR}
              className="p-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors shadow-sm"
              title="Regenerate"
            >
              <RefreshCw size={20} />
            </button>
            <button
              onClick={downloadQR}
              className="flex items-center gap-2 px-6 py-3 bg-primary hover:bg-indigo-600 text-white font-bold rounded-xl transition-colors shadow-lg shadow-primary/30"
            >
              <Download size={20} /> Download PNG
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QrCodeGenerator;