import React, { useState, useCallback, useEffect } from 'react';
import { Copy, RefreshCw, Check } from 'lucide-react';

const PasswordGenerator: React.FC = () => {
  const [password, setPassword] = useState('');
  const [length, setLength] = useState(16);
  const [options, setOptions] = useState({
    uppercase: true,
    lowercase: true,
    numbers: true,
    symbols: true,
  });
  const [copied, setCopied] = useState(false);
  const [strength, setStrength] = useState(0);

  const generatePassword = useCallback(() => {
    const charset = {
      uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
      lowercase: 'abcdefghijklmnopqrstuvwxyz',
      numbers: '0123456789',
      symbols: '!@#$%^&*()_+~`|}{[]:;?><,./-=',
    };

    let validChars = '';
    if (options.uppercase) validChars += charset.uppercase;
    if (options.lowercase) validChars += charset.lowercase;
    if (options.numbers) validChars += charset.numbers;
    if (options.symbols) validChars += charset.symbols;

    if (validChars === '') return;

    let generated = '';
    const array = new Uint32Array(length);
    window.crypto.getRandomValues(array);

    for (let i = 0; i < length; i++) {
      generated += validChars.charAt(array[i] % validChars.length);
    }

    setPassword(generated);
    calculateStrength(generated);
  }, [length, options]);

  const calculateStrength = (pwd: string) => {
    let score = 0;
    if (pwd.length > 8) score += 1;
    if (pwd.length > 12) score += 1;
    if (/[A-Z]/.test(pwd)) score += 1;
    if (/[0-9]/.test(pwd)) score += 1;
    if (/[^A-Za-z0-9]/.test(pwd)) score += 1;
    setStrength(score);
  };

  useEffect(() => {
    generatePassword();
  }, [generatePassword]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(password);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-2xl mx-auto animate-slide-up">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Password Generator</h2>
        <p className="text-slate-500 dark:text-slate-400">Generate cryptographically secure passwords instantly.</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl shadow-slate-200/50 dark:shadow-black/20 overflow-hidden border border-slate-200 dark:border-slate-800">
        {/* Output Area */}
        <div className="p-8 bg-slate-50 dark:bg-slate-950/50 border-b border-slate-200 dark:border-slate-800 text-center relative">
          <div className="text-3xl md:text-4xl font-mono text-slate-800 dark:text-slate-100 break-all mb-4 tracking-wider min-h-[3rem] flex items-center justify-center">
            {password}
          </div>
          
          <div className="flex justify-center gap-4">
             <button 
               onClick={generatePassword} 
               className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors text-sm font-medium"
             >
               <RefreshCw size={16} /> Regenerate
             </button>
             <button 
               onClick={copyToClipboard}
               className={`flex items-center gap-2 px-6 py-2 rounded-lg transition-all text-sm font-bold text-white shadow-lg ${copied ? 'bg-green-500 scale-105' : 'bg-primary hover:bg-indigo-500 active:scale-95'}`}
             >
               {copied ? <Check size={16} /> : <Copy size={16} />}
               {copied ? 'Copied' : 'Copy'}
             </button>
          </div>
        </div>

        {/* Controls */}
        <div className="p-8 space-y-8">
           {/* Slider */}
           <div>
             <div className="flex justify-between mb-2">
               <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">Password Length</label>
               <span className="text-primary font-bold">{length}</span>
             </div>
             <input 
               type="range" 
               min="6" 
               max="64" 
               value={length} 
               onChange={(e) => setLength(parseInt(e.target.value))}
               className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-primary"
             />
           </div>

           {/* Checkboxes */}
           <div className="grid grid-cols-2 gap-4">
             {Object.keys(options).map((key) => (
               <label key={key} className="flex items-center gap-3 p-4 border border-slate-200 dark:border-slate-800 rounded-xl cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                 <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${options[key as keyof typeof options] ? 'bg-primary border-primary' : 'border-slate-400 bg-transparent'}`}>
                    {options[key as keyof typeof options] && <Check size={12} className="text-white" />}
                 </div>
                 <input 
                   type="checkbox" 
                   checked={options[key as keyof typeof options]}
                   onChange={() => setOptions(prev => ({ ...prev, [key]: !prev[key as keyof typeof options] }))}
                   className="hidden"
                 />
                 <span className="capitalize text-slate-700 dark:text-slate-300 font-medium">{key}</span>
               </label>
             ))}
           </div>

           {/* Strength Meter */}
           <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold uppercase text-slate-500 tracking-wider">
                <span>Strength</span>
                <span>{['Weak', 'Fair', 'Good', 'Strong', 'Excellent'][Math.min(strength, 4)]}</span>
              </div>
              <div className="flex gap-1 h-2">
                 {[0,1,2,3,4].map((i) => (
                    <div 
                      key={i} 
                      className={`flex-1 rounded-full transition-all duration-500 ${i < strength ? (strength > 3 ? 'bg-green-500' : strength > 2 ? 'bg-blue-500' : 'bg-yellow-500') : 'bg-slate-200 dark:bg-slate-800'}`}
                    ></div>
                 ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default PasswordGenerator;
