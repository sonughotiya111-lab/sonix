import React, { useState, useRef } from 'react';
import { Copy, Upload, Check, Palette } from 'lucide-react';

const ColorPicker: React.FC = () => {
  const [color, setColor] = useState('#6366f1');
  const [palette, setPalette] = useState<string[]>([]);
  const [image, setImage] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setColor(e.target.value);
  };

  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}` : '';
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          extractPalette(img);
          setImage(event.target?.result as string);
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const extractPalette = (img: HTMLImageElement) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 100; // Small size for performance
    canvas.height = 100;
    ctx.drawImage(img, 0, 0, 100, 100);

    const imageData = ctx.getImageData(0, 0, 100, 100).data;
    const colorCounts: Record<string, number> = {};

    // Simple quantization
    for (let i = 0; i < imageData.length; i += 4) {
      const r = Math.round(imageData[i] / 10) * 10;
      const g = Math.round(imageData[i + 1] / 10) * 10;
      const b = Math.round(imageData[i + 2] / 10) * 10;
      const hex = `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
      colorCounts[hex] = (colorCounts[hex] || 0) + 1;
    }

    const sorted = Object.entries(colorCounts).sort((a, b) => b[1] - a[1]);
    setPalette(sorted.slice(0, 6).map(([c]) => c));
  };

  const CopyButton = ({ text }: { text: string }) => {
    const [copied, setCopied] = useState(false);
    const copy = () => {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    };
    return (
      <button onClick={copy} className="p-2 hover:bg-white/20 rounded-lg transition-colors" title="Copy">
        {copied ? <Check size={16} /> : <Copy size={16} />}
      </button>
    );
  };

  return (
    <div className="max-w-4xl mx-auto animate-slide-up">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Color Studio</h2>
        <p className="text-slate-500 dark:text-slate-400">Pick colors and extract palettes from images.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Picker Section */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
            <h3 className="font-bold mb-4 flex items-center gap-2"><Palette size={18} /> Picker</h3>
            <div className="flex gap-4 items-start">
              <input 
                type="color" 
                value={color} 
                onChange={handleColorChange}
                className="w-20 h-20 rounded-xl cursor-pointer border-0 p-0 shadow-lg"
              />
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                  <span className="font-mono text-slate-600 dark:text-slate-300 uppercase">{color}</span>
                  <CopyButton text={color} />
                </div>
                <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                  <span className="font-mono text-slate-600 dark:text-slate-300">rgb({hexToRgb(color)})</span>
                  <CopyButton text={`rgb(${hexToRgb(color)})`} />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Extractor Section */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
            <h3 className="font-bold mb-4 flex items-center gap-2"><Upload size={18} /> Palette Extractor</h3>
            
            <div className="mb-4">
              <label className="block w-full cursor-pointer">
                <div className="flex items-center justify-center w-full h-32 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                   <div className="text-center text-slate-500">
                     <span className="text-sm font-semibold">Click to upload image</span>
                   </div>
                </div>
                <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
              </label>
            </div>

            <canvas ref={canvasRef} className="hidden"></canvas>
            
            {palette.length > 0 && (
              <div className="space-y-3">
                 <div className="text-sm font-semibold text-slate-500">Dominant Colors</div>
                 <div className="grid grid-cols-3 gap-3">
                    {palette.map((c, i) => (
                      <div key={i} className="group relative h-16 rounded-xl shadow-sm transition-transform hover:scale-105" style={{ backgroundColor: c }}>
                         <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/20 rounded-xl transition-opacity text-white">
                           <span className="sr-only">{c}</span>
                           <CopyButton text={c} />
                         </div>
                         <span className="absolute bottom-1 right-2 text-[10px] bg-black/40 text-white px-1 rounded opacity-0 group-hover:opacity-100">{c}</span>
                      </div>
                    ))}
                 </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ColorPicker;