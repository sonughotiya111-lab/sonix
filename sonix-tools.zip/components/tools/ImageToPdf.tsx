import React, { useState } from 'react';
import { Images, FileText } from 'lucide-react';
import { useToast } from '../ToastContext';

declare const PDFLib: any;

const ImageToPdf: React.FC = () => {
  const { showToast } = useToast();
  const [images, setImages] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
       setImages(Array.from(e.target.files));
    }
  };

  const convert = async () => {
    if (typeof PDFLib === 'undefined') {
       showToast("PDF Lib missing", "error");
       return;
    }
    setIsProcessing(true);
    try {
      const pdfDoc = await PDFLib.PDFDocument.create();
      
      for (const imgFile of images) {
         const imgBytes = await imgFile.arrayBuffer();
         let img;
         if (imgFile.type === 'image/png') {
            img = await pdfDoc.embedPng(imgBytes);
         } else {
            img = await pdfDoc.embedJpg(imgBytes);
         }
         
         const page = pdfDoc.addPage([img.width, img.height]);
         page.drawImage(img, {
            x: 0,
            y: 0,
            width: img.width,
            height: img.height,
         });
      }

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = "images.pdf";
      link.click();
      showToast("PDF created successfully!");
    } catch (e) {
      showToast("Conversion failed (ensure JPG/PNG)", "error");
    }
    setIsProcessing(false);
  };

  return (
    <div className="max-w-3xl mx-auto animate-slide-up">
       <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Image to PDF</h2>
        <p className="text-slate-500 dark:text-slate-400">Convert sequence of images into a single PDF document.</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-xl">
         <label className="flex flex-col items-center justify-center h-32 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors mb-6">
            <Images size={32} className="text-slate-400 mb-2" />
            <span className="font-semibold">Select Images (JPG/PNG)</span>
            <input type="file" multiple accept="image/png, image/jpeg" className="hidden" onChange={handleFileChange} />
         </label>

         {images.length > 0 && (
            <div>
               <div className="text-sm font-bold mb-2 text-slate-500">Selected {images.length} images</div>
               <button onClick={convert} disabled={isProcessing} className="w-full py-3 bg-primary text-white rounded-xl font-bold hover:bg-indigo-600 transition-colors shadow-lg">
                  {isProcessing ? 'Generating PDF...' : 'Convert to PDF'}
               </button>
            </div>
         )}
      </div>
    </div>
  );
};

export default ImageToPdf;
