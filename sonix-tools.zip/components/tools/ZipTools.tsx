import React, { useState } from 'react';
import { FilePlus, FileBox, Download } from 'lucide-react';
import { useToast } from '../ToastContext';

declare const JSZip: any;

const ZipTools: React.FC = () => {
  const { showToast } = useToast();
  const [files, setFiles] = useState<File[]>([]);
  const [isZipping, setIsZipping] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(prev => [...prev, ...Array.from(e.target.files || [])]);
    }
  };

  const createZip = async () => {
    if (typeof JSZip === 'undefined') {
       showToast("JSZip library missing", "error");
       return;
    }
    setIsZipping(true);
    const zip = new JSZip();
    
    files.forEach(file => {
       zip.file(file.name, file);
    });

    try {
      const content = await zip.generateAsync({ type: "blob" });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(content);
      link.download = "archive.zip";
      link.click();
      showToast("Zip archive created!");
    } catch (e) {
      showToast("Error creating zip", "error");
    }
    setIsZipping(false);
  };

  return (
    <div className="max-w-3xl mx-auto animate-slide-up">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Zip Archiver</h2>
        <p className="text-slate-500 dark:text-slate-400">Combine multiple files into a single ZIP archive locally.</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-xl">
         <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl p-10 bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors mb-6">
          <input
            type="file"
            multiple
            onChange={handleFileChange}
            className="hidden"
            id="zip-upload"
          />
          <label htmlFor="zip-upload" className="cursor-pointer flex flex-col items-center text-center w-full">
            <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center text-blue-500 mb-4">
              <FilePlus size={32} />
            </div>
            <h3 className="text-lg font-bold">Add Files</h3>
          </label>
        </div>

        {files.length > 0 && (
           <div className="space-y-4">
              <div className="max-h-60 overflow-y-auto space-y-2">
                 {files.map((f, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-100 dark:border-slate-800">
                       <FileBox size={16} className="text-primary" />
                       <span className="text-sm truncate flex-1">{f.name}</span>
                       <span className="text-xs text-slate-400">{(f.size/1024).toFixed(1)} KB</span>
                    </div>
                 ))}
              </div>
              <button 
                 onClick={createZip} 
                 disabled={isZipping}
                 className="w-full py-3 bg-primary text-white rounded-xl font-bold shadow-lg hover:bg-indigo-600 transition-colors flex items-center justify-center gap-2"
              >
                 {isZipping ? 'Compressing...' : <><Download size={18} /> Download .ZIP</>}
              </button>
           </div>
        )}
      </div>
    </div>
  );
};

export default ZipTools;
