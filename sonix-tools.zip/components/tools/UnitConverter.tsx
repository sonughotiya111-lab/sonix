import React, { useState, useEffect } from 'react';
import { ArrowRightLeft } from 'lucide-react';

type UnitType = 'length' | 'mass' | 'temperature';

const UNITS: Record<UnitType, Record<string, number | ((val: number) => number)>> = {
  length: {
    'Meters (m)': 1,
    'Kilometers (km)': 1000,
    'Centimeters (cm)': 0.01,
    'Millimeters (mm)': 0.001,
    'Miles (mi)': 1609.34,
    'Yards (yd)': 0.9144,
    'Feet (ft)': 0.3048,
    'Inches (in)': 0.0254,
  },
  mass: {
    'Kilograms (kg)': 1,
    'Grams (g)': 0.001,
    'Pounds (lb)': 0.453592,
    'Ounces (oz)': 0.0283495,
  },
  temperature: {
    // Temp handles offsets differently, simplified here for multiplier-based, 
    // real impl would need specific logic blocks.
    'Celsius': 1, // Placeholder
    'Fahrenheit': 1, 
    'Kelvin': 1,
  }
};

const UnitConverter: React.FC = () => {
  const [category, setCategory] = useState<UnitType>('length');
  const [fromUnit, setFromUnit] = useState(Object.keys(UNITS.length)[0]);
  const [toUnit, setToUnit] = useState(Object.keys(UNITS.length)[1]);
  const [value, setValue] = useState<string>('1');
  const [result, setResult] = useState<string>('');

  useEffect(() => {
    // Reset units when category changes
    setFromUnit(Object.keys(UNITS[category])[0]);
    setToUnit(Object.keys(UNITS[category])[1]);
  }, [category]);

  useEffect(() => {
    const val = parseFloat(value);
    if (isNaN(val)) {
      setResult('---');
      return;
    }

    let res = 0;

    // Special handling for Temperature
    if (category === 'temperature') {
      if (fromUnit === toUnit) res = val;
      else if (fromUnit === 'Celsius' && toUnit === 'Fahrenheit') res = (val * 9/5) + 32;
      else if (fromUnit === 'Celsius' && toUnit === 'Kelvin') res = val + 273.15;
      else if (fromUnit === 'Fahrenheit' && toUnit === 'Celsius') res = (val - 32) * 5/9;
      else if (fromUnit === 'Fahrenheit' && toUnit === 'Kelvin') res = (val - 32) * 5/9 + 273.15;
      else if (fromUnit === 'Kelvin' && toUnit === 'Celsius') res = val - 273.15;
      else if (fromUnit === 'Kelvin' && toUnit === 'Fahrenheit') res = (val - 273.15) * 9/5 + 32;
    } else {
      // Standard multiplier logic: (Value * FromFactor) / ToFactor
      // Wait, FACTORS are in base unit (e.g. meters).
      // 1 km = 1000m. 
      // To convert 5 km to meters: 5 * 1000 = 5000.
      // To convert 5000m to km: 5000 / 1000 = 5.
      
      const fromFactor = UNITS[category][fromUnit] as number;
      const toFactor = UNITS[category][toUnit] as number;
      
      const baseValue = val * fromFactor;
      res = baseValue / toFactor;
    }

    setResult(res.toLocaleString(undefined, { maximumFractionDigits: 4 }));
  }, [value, fromUnit, toUnit, category]);

  return (
    <div className="max-w-2xl mx-auto animate-slide-up">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Unit Converter</h2>
        <p className="text-slate-500 dark:text-slate-400">Convert between common units of measurement.</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 md:p-8 border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20">
        
        {/* Category Selector */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2 no-scrollbar">
          {(Object.keys(UNITS) as UnitType[]).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-semibold capitalize whitespace-nowrap transition-colors ${
                category === cat 
                ? 'bg-primary text-white shadow-md shadow-primary/25' 
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex flex-col md:flex-row items-center gap-6">
          {/* From */}
          <div className="flex-1 w-full space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">From</label>
            <input 
              type="number" 
              value={value} 
              onChange={(e) => setValue(e.target.value)}
              className="w-full text-3xl font-bold bg-transparent border-b-2 border-slate-200 dark:border-slate-700 focus:border-primary outline-none py-2 text-slate-800 dark:text-white transition-colors"
            />
            <select 
              value={fromUnit}
              onChange={(e) => setFromUnit(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-sm outline-none focus:ring-2 focus:ring-primary/50"
            >
              {Object.keys(UNITS[category]).map(u => <option key={u} value={u}>{u}</option>)}
            </select>
          </div>

          <div className="text-slate-300 dark:text-slate-600">
            <ArrowRightLeft size={24} className="md:rotate-0 rotate-90" />
          </div>

          {/* To */}
          <div className="flex-1 w-full space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">To</label>
             <div className="w-full text-3xl font-bold border-b-2 border-transparent py-2 text-primary overflow-hidden text-ellipsis">
               {result}
             </div>
             <select 
              value={toUnit}
              onChange={(e) => setToUnit(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-sm outline-none focus:ring-2 focus:ring-primary/50"
            >
              {Object.keys(UNITS[category]).map(u => <option key={u} value={u}>{u}</option>)}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnitConverter;
