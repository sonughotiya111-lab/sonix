import React, { useState, useRef } from 'react';
import { Upload, Download, Image as ImageIcon, X } from 'lucide-react';

interface ProcessedImage {
  name: string;
  originalSize: number;
  compressedSize: number;
  blob: Blob;
  previewUrl: string;
}

const ImageCompressor: React.FC = () => {
  const [quality, setQuality] = useState(0.8);
  const [width, setWidth] = useState<number | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<ProcessedImage | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processImage(file);
  };

  const processImage = async (file: File) => {
    setIsProcessing(true);
    setResult(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        let targetWidth = width || img.width;
        let targetHeight = (img.height / img.width) * targetWidth;

        canvas.width = targetWidth;
        canvas.height = targetHeight;

        if (ctx) {
          ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
          
          canvas.toBlob(
            (blob) => {
              if (blob) {
                const previewUrl = URL.createObjectURL(blob);
                setResult({
                  name: file.name,
                  originalSize: file.size,
                  compressedSize: blob.size,
                  blob,
                  previewUrl
                });
              }
              setIsProcessing(false);
            },
            'image/jpeg',
            quality
          );
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="max-w-4xl mx-auto animate-slide-up">
       <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Image Compressor</h2>
        <p className="text-slate-500 dark:text-slate-400">Compress JPG/PNG images client-side without quality loss.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Controls */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm h-fit">
           <div className="space-y-6">
             <div>
               <label className="block text-sm font-semibold mb-2">Compression Quality: {Math.round(quality * 100)}%</label>
               <input 
                 type="range" 
                 min="0.1" 
                 max="1.0" 
                 step="0.05"
                 value={quality}
                 onChange={(e) => setQuality(parseFloat(e.target.value))}
                 className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-primary"
               />
               <div className="flex justify-between text-xs text-slate-400 mt-1">
                 <span>Smaller Size</span>
                 <span>Better Quality</span>
               </div>
             </div>

             <div>
               <label className="block text-sm font-semibold mb-2">Max Width (px)</label>
               <input 
                 type="number" 
                 placeholder="Auto (Original)"
                 value={width || ''}
                 onChange={(e) => setWidth(e.target.value ? parseInt(e.target.value) : null)}
                 className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary/50 outline-none"
               />
             </div>

             <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full py-4 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl flex flex-col items-center justify-center text-slate-500 hover:border-primary hover:text-primary transition-colors bg-slate-50 dark:bg-slate-800/50"
                >
                  <Upload className="mb-2" />
                  <span className="font-semibold">Select Image</span>
                  <span className="text-xs mt-1 opacity-70">JPG, PNG supported</span>
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  accept="image/*" 
                  className="hidden" 
                />
             </div>
           </div>
        </div>

        {/* Preview */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm min-h-[300px] flex items-center justify-center relative">
           {isProcessing ? (
             <div className="flex flex-col items-center gap-3 animate-pulse">
               <ImageIcon size={48} className="text-slate-300" />
               <span className="text-sm font-medium text-slate-500">Processing...</span>
             </div>
           ) : result ? (
             <div className="w-full space-y-4">
                <div className="relative rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <img src={result.previewUrl} alt="Preview" className="w-full h-auto max-h-[300px] object-contain" />
                  <button onClick={() => setResult(null)} className="absolute top-2 right-2 p-1 bg-black/50 text-white rounded-full hover:bg-black/70">
                    <X size={16} />
                  </button>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                   <div className="p-3 bg-red-50 dark:bg-red-900/10 rounded-lg border border-red-100 dark:border-red-900/20">
                     <div className="text-red-500 font-semibold mb-1">Original</div>
                     <div className="text-slate-700 dark:text-slate-300 font-mono">{formatBytes(result.originalSize)}</div>
                   </div>
                   <div className="p-3 bg-green-50 dark:bg-green-900/10 rounded-lg border border-green-100 dark:border-green-900/20">
                     <div className="text-green-500 font-semibold mb-1">Compressed</div>
                     <div className="text-slate-700 dark:text-slate-300 font-mono">{formatBytes(result.compressedSize)}</div>
                     <div className="text-xs text-green-600 font-bold mt-1">
                        -{Math.round(((result.originalSize - result.compressedSize) / result.originalSize) * 100)}% saved
                     </div>
                   </div>
                </div>

                <a 
                  href={result.previewUrl} 
                  download={`compressed-${result.name}`}
                  className="flex items-center justify-center gap-2 w-full py-3 bg-primary hover:bg-indigo-600 text-white font-bold rounded-xl transition-colors shadow-lg shadow-primary/30"
                >
                  <Download size={18} /> Download
                </a>
             </div>
           ) : (
             <div className="text-center text-slate-400">
               <ImageIcon size={48} className="mx-auto mb-3 opacity-50" />
               <p>No image selected</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default ImageCompressor;
