import React, { useRef, useState, useEffect } from 'react';
import { Camera, Image as ImageIcon, StopCircle, Copy, Check, ExternalLink, RefreshCw, Zap, Maximize } from 'lucide-react';
import { useToast } from '../ToastContext';

declare const jsQR: any;

const QrReader: React.FC = () => {
  const { showToast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [result, setResult] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState(false);
  const requestRef = useRef<number>();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startCamera = async () => {
    setCameraError(false);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: "environment" } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute("playsinline", "true");
        // Wait for video to be ready
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
          setIsCameraActive(true);
          setIsScanning(true);
          requestRef.current = requestAnimationFrame(tick);
        };
      }
    } catch (err) {
      console.error(err);
      setCameraError(true);
      showToast("Could not access camera. Try uploading an image.", "error");
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsCameraActive(false);
      setIsScanning(false);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    }
  };

  const tick = () => {
    if (videoRef.current && canvasRef.current && isScanning) {
      if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        const canvas = canvasRef.current;
        const video = videoRef.current;
        
        canvas.height = video.videoHeight;
        canvas.width = video.videoWidth;
        
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          
          if (typeof jsQR !== 'undefined') {
             const code = jsQR(imageData.data, imageData.width, imageData.height, {
               inversionAttempts: "dontInvert",
             });
             
             if (code) {
               handleScanSuccess(code.data);
               return;
             }
          }
        }
      }
      requestRef.current = requestAnimationFrame(tick);
    }
  };

  const handleScanSuccess = (data: string) => {
    setResult(data);
    showToast("Target Acquired", "success");
    stopCamera();
    
    // Haptic feedback if available
    if (navigator.vibrate) {
      navigator.vibrate([100, 50, 100]);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
           const canvas = document.createElement('canvas');
           canvas.width = img.width;
           canvas.height = img.height;
           const ctx = canvas.getContext('2d');
           if (ctx) {
             ctx.drawImage(img, 0, 0);
             const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
             if (typeof jsQR !== 'undefined') {
               const code = jsQR(imageData.data, imageData.width, imageData.height);
               if (code) {
                 handleScanSuccess(code.data);
               } else {
                 showToast("No QR code found in image", "error");
               }
             } else {
               showToast("Library loading...", "error");
             }
           }
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const copyResult = () => {
    if(result) {
        navigator.clipboard.writeText(result);
        showToast("Copied to clipboard");
    }
  };

  const resetScan = () => {
    setResult(null);
    startCamera();
  };

  // Auto-start camera on mount
  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  return (
    <div className="max-w-2xl mx-auto h-[calc(100vh-8rem)] flex flex-col animate-slide-up">
      <div className="flex-1 flex flex-col gap-4 relative">
        
        {/* Camera/Result Area */}
        <div className="relative w-full flex-1 bg-black rounded-3xl overflow-hidden shadow-2xl border border-slate-800 flex items-center justify-center group isolate">
          
          {/* Active Camera View */}
          {isCameraActive && !result && (
            <>
              <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" />
              <canvas ref={canvasRef} className="hidden" />
              
              {/* Darkened Mask Overlay */}
              <div className="absolute inset-0 bg-black/40 pointer-events-none"></div>

              {/* Sci-Fi HUD Layer */}
              <div className="absolute inset-0 z-10 flex flex-col items-center justify-center pointer-events-none">
                 
                 {/* Focus Area */}
                 <div className="relative w-72 h-72">
                    {/* Glowing Brackets */}
                    <div className="absolute -top-1 -left-1 w-12 h-12 border-t-4 border-l-4 border-primary rounded-tl-2xl shadow-[0_0_15px_#6366f1] animate-breathe"></div>
                    <div className="absolute -top-1 -right-1 w-12 h-12 border-t-4 border-r-4 border-primary rounded-tr-2xl shadow-[0_0_15px_#6366f1] animate-breathe"></div>
                    <div className="absolute -bottom-1 -left-1 w-12 h-12 border-b-4 border-l-4 border-primary rounded-bl-2xl shadow-[0_0_15px_#6366f1] animate-breathe"></div>
                    <div className="absolute -bottom-1 -right-1 w-12 h-12 border-b-4 border-r-4 border-primary rounded-br-2xl shadow-[0_0_15px_#6366f1] animate-breathe"></div>
                    
                    {/* Tech Grid Background inside focus */}
                    <div className="absolute inset-0 opacity-20 bg-[linear-gradient(rgba(99,102,241,0.5)_1px,transparent_1px),linear-gradient(90deg,rgba(99,102,241,0.5)_1px,transparent_1px)] bg-[size:20px_20px]"></div>

                    {/* Radar Sweep Animation */}
                    <div className="absolute inset-0 overflow-hidden rounded-xl">
                      <div className="w-full h-1/2 bg-gradient-to-b from-transparent to-primary/30 animate-scan-radar border-b-2 border-primary/60 shadow-[0_0_20px_#6366f1]"></div>
                    </div>

                    {/* Central Crosshair */}
                    <div className="absolute top-1/2 left-1/2 w-4 h-4 -translate-x-1/2 -translate-y-1/2">
                       <div className="absolute top-0 left-1/2 w-[1px] h-full bg-primary/50 -translate-x-1/2"></div>
                       <div className="absolute top-1/2 left-0 w-full h-[1px] bg-primary/50 -translate-y-1/2"></div>
                    </div>
                 </div>

                 {/* Status Text */}
                 <div className="mt-8 flex items-center gap-2 px-4 py-1.5 bg-black/60 backdrop-blur-md rounded-full border border-primary/30 text-primary-200 text-xs font-mono tracking-widest uppercase">
                   <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                   <span>System Active • Searching...</span>
                 </div>
              </div>

              {/* Tech Data Overlay (Decorative) */}
              <div className="absolute top-4 left-4 text-[10px] font-mono text-primary/60 opacity-70 pointer-events-none hidden md:block">
                 <div>FPS: 60</div>
                 <div>ISO: AUTO</div>
                 <div>W: {videoRef.current?.videoWidth} H: {videoRef.current?.videoHeight}</div>
              </div>

              {/* Stop Button */}
              <button 
                onClick={stopCamera} 
                className="absolute top-4 right-4 p-3 bg-black/40 text-white rounded-full hover:bg-red-500/80 backdrop-blur-md transition-colors z-20 border border-white/10"
              >
                <StopCircle size={24} />
              </button>
            </>
          )}

          {/* Result View */}
          {result && (
             <div className="absolute inset-0 bg-slate-900/95 flex flex-col items-center justify-center p-6 text-center animate-fade-in z-30 backdrop-blur-md">
                <div className="w-20 h-20 bg-gradient-to-tr from-green-400 to-emerald-600 rounded-full flex items-center justify-center text-white mb-6 shadow-[0_0_30px_rgba(74,222,128,0.4)] animate-slide-up">
                   <Check size={40} />
                </div>
                <h3 className="text-white text-2xl font-bold mb-2">Target Acquired</h3>
                <div className="bg-slate-800/80 p-5 rounded-2xl w-full max-w-sm mb-8 border border-slate-700/50 break-all shadow-xl">
                   <p className="text-slate-200 font-mono text-sm leading-relaxed">{result}</p>
                </div>
                
                <div className="flex flex-col w-full max-w-xs gap-3">
                   {result.startsWith('http') && (
                     <a href={result} target="_blank" rel="noreferrer" className="w-full py-4 bg-primary text-white rounded-xl font-bold shadow-lg shadow-primary/20 flex items-center justify-center gap-2 hover:scale-[1.02] transition-transform">
                        <ExternalLink size={20} /> Open Link
                     </a>
                   )}
                   <div className="grid grid-cols-2 gap-3">
                     <button onClick={copyResult} className="w-full py-3 bg-slate-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-700 transition-colors border border-slate-700">
                        <Copy size={18} /> Copy
                     </button>
                     <button onClick={resetScan} className="w-full py-3 bg-white text-slate-900 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-200 transition-colors">
                        <RefreshCw size={18} /> New Scan
                     </button>
                   </div>
                </div>
             </div>
          )}

          {/* Error/Start View */}
          {!isCameraActive && !result && (
             <div className="flex flex-col items-center justify-center p-6 text-center">
                <div className="relative mb-6">
                   <div className="w-20 h-20 bg-slate-800/80 rounded-3xl flex items-center justify-center text-slate-500 backdrop-blur-sm border border-slate-700">
                      <Camera size={40} />
                   </div>
                   <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full border-2 border-black flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                   </div>
                </div>
                <h3 className="text-lg font-bold text-slate-200 mb-2">Camera Offline</h3>
                <p className="text-slate-400 max-w-xs mb-8 text-sm">
                   {cameraError ? "Access denied or unavailable." : "Initialize scanner to begin detection."}
                </p>
                <button onClick={startCamera} className="px-8 py-3 bg-primary text-white rounded-xl font-bold shadow-[0_0_20px_rgba(99,102,241,0.4)] hover:scale-105 transition-transform flex items-center gap-2">
                   <Zap size={18} /> Activate Scanner
                </button>
             </div>
          )}
        </div>

        {/* Bottom Action Area (Upload) */}
        <div className="bg-white dark:bg-slate-900/80 backdrop-blur-md rounded-2xl p-4 shadow-xl border border-slate-200 dark:border-slate-800 flex items-center gap-4">
           <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500">
              <ImageIcon size={20} />
           </div>
           <div className="flex-1">
              <p className="text-sm font-bold text-slate-700 dark:text-slate-200">Manual Override</p>
              <p className="text-[10px] text-slate-500 uppercase tracking-wide">Select image from gallery</p>
           </div>
           
           <button 
             onClick={() => fileInputRef.current?.click()}
             className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-semibold text-sm transition-colors border border-slate-200 dark:border-slate-700"
           >
             Upload
           </button>
           <input 
             ref={fileInputRef}
             type="file" 
             accept="image/*" 
             className="hidden" 
             onChange={handleFileUpload} 
           />
        </div>

      </div>
    </div>
  );
};

export default QrReader;