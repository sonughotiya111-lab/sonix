import React, { useState } from 'react';
import { Upload, Download, ArrowRight } from 'lucide-react';
import { useToast } from '../ToastContext';

const ImageConverter: React.FC = () => {
  const { showToast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [format, setFormat] = useState('image/webp');
  const [preview, setPreview] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      setPreview(URL.createObjectURL(f));
    }
  };

  const convertAndDownload = () => {
    if (!file) return;

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        const dataUrl = canvas.toDataURL(format, 0.9);
        const link = document.createElement('a');
        const ext = format.split('/')[1];
        link.download = `converted.${ext}`;
        link.href = dataUrl;
        link.click();
        showToast("Image converted successfully!");
      }
    };
    img.src = preview!;
  };

  return (
    <div className="max-w-2xl mx-auto animate-slide-up">
       <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Image Converter</h2>
        <p className="text-slate-500 dark:text-slate-400">Convert images between JPG, PNG, and WebP formats.</p>
      </div>
      
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
         <div className="mb-6">
            <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer transition-colors">
               {preview ? (
                  <img src={preview} alt="Preview" className="h-full object-contain p-2" />
               ) : (
                  <div className="flex flex-col items-center text-slate-400">
                     <Upload size={32} className="mb-2" />
                     <span className="font-semibold">Select Image</span>
                  </div>
               )}
               <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
            </label>
         </div>

         {file && (
            <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-800 p-4 rounded-xl">
               <div className="flex-1">
                  <div className="text-sm font-semibold mb-1">Target Format</div>
                  <select 
                    value={format} 
                    onChange={e => setFormat(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg p-2"
                  >
                     <option value="image/jpeg">JPEG</option>
                     <option value="image/png">PNG</option>
                     <option value="image/webp">WebP</option>
                  </select>
               </div>
               <ArrowRight className="text-slate-400 mt-6" />
               <div className="flex-1 flex items-end">
                  <button onClick={convertAndDownload} className="w-full py-2 bg-primary text-white rounded-lg font-bold shadow-lg hover:bg-indigo-600 transition-colors flex items-center justify-center gap-2">
                     <Download size={18} /> Convert
                  </button>
               </div>
            </div>
         )}
      </div>
    </div>
  );
};

export default ImageConverter;
