import React, { useState, useEffect, useRef } from 'react';
import { Download, RefreshCw } from 'lucide-react';

declare const JsBarcode: any;

const BarcodeGenerator: React.FC = () => {
  const [value, setValue] = useState('123456789');
  const [format, setFormat] = useState('CODE128');
  const svgRef = useRef<SVGSVGElement>(null);

  const generate = () => {
    if (typeof JsBarcode !== 'undefined' && svgRef.current) {
       try {
         JsBarcode(svgRef.current, value, {
           format: format,
           lineColor: "#000",
           width: 2,
           height: 100,
           displayValue: true
         });
       } catch(e) {
         // Invalid content for format
       }
    }
  };

  useEffect(() => {
    const timer = setTimeout(generate, 300);
    return () => clearTimeout(timer);
  }, [value, format]);

  const download = () => {
    const svg = svgRef.current;
    if (svg) {
       const svgData = new XMLSerializer().serializeToString(svg);
       const canvas = document.createElement("canvas");
       const ctx = canvas.getContext("2d");
       const img = new Image();
       img.onload = () => {
         canvas.width = img.width;
         canvas.height = img.height;
         ctx?.drawImage(img, 0, 0);
         const a = document.createElement("a");
         a.download = `barcode-${value}.png`;
         a.href = canvas.toDataURL("image/png");
         a.click();
       };
       img.src = "data:image/svg+xml;base64," + btoa(svgData);
    }
  };

  return (
    <div className="max-w-3xl mx-auto animate-slide-up">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Barcode Generator</h2>
        <p className="text-slate-500 dark:text-slate-400">Generate customizable barcodes (EAN, Code128, etc).</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-xl">
         <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="md:col-span-2">
               <label className="block text-sm font-semibold mb-2">Content</label>
               <input 
                 type="text" 
                 value={value} 
                 onChange={e => setValue(e.target.value)} 
                 className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary/50 outline-none"
               />
            </div>
            <div>
               <label className="block text-sm font-semibold mb-2">Format</label>
               <select 
                 value={format} 
                 onChange={e => setFormat(e.target.value)}
                 className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary/50 outline-none"
               >
                 <option value="CODE128">Code 128</option>
                 <option value="EAN13">EAN 13</option>
                 <option value="UPC">UPC</option>
                 <option value="CODE39">Code 39</option>
               </select>
            </div>
         </div>

         <div className="flex flex-col items-center justify-center p-8 bg-white rounded-xl border border-slate-200 min-h-[200px] mb-6">
            <svg ref={svgRef}></svg>
         </div>

         <div className="flex justify-center">
            <button onClick={download} className="flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-xl font-bold hover:bg-indigo-600 transition-colors shadow-lg shadow-primary/30">
               <Download size={20} /> Download PNG
            </button>
         </div>
      </div>
    </div>
  );
};

export default BarcodeGenerator;
