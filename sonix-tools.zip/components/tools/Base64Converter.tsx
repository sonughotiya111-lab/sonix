import React, { useState } from 'react';
import { FileUp, Copy, Download } from 'lucide-react';
import { useToast } from '../ToastContext';

const Base64Converter: React.FC = () => {
  const { showToast } = useToast();
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setInput(ev.target?.result as string);
        showToast("File encoded to Base64");
      };
      reader.readAsDataURL(file);
    }
  };

  const copy = () => {
    navigator.clipboard.writeText(input);
    showToast("Copied to clipboard");
  };

  const downloadDecode = () => {
     try {
       const link = document.createElement('a');
       link.href = input;
       link.download = 'decoded-file';
       link.click();
     } catch (e) {
       showToast("Invalid Base64 string", "error");
     }
  };

  return (
    <div className="max-w-3xl mx-auto animate-slide-up">
       <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Base64 Converter</h2>
        <p className="text-slate-500 dark:text-slate-400">Encode files to Base64 or decode Base64 strings to files.</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
         <div className="flex gap-4 mb-6">
            <button onClick={() => setMode('encode')} className={`flex-1 py-2 rounded-xl font-bold transition-colors ${mode === 'encode' ? 'bg-primary text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>Encode</button>
            <button onClick={() => setMode('decode')} className={`flex-1 py-2 rounded-xl font-bold transition-colors ${mode === 'decode' ? 'bg-primary text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>Decode</button>
         </div>

         {mode === 'encode' && (
            <div className="mb-4">
               <label className="flex items-center gap-2 cursor-pointer p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-dashed border-slate-300 hover:bg-slate-100 transition-colors">
                  <FileUp size={20} />
                  <span className="font-semibold text-sm">Upload file to encode</span>
                  <input type="file" className="hidden" onChange={handleFileUpload} />
               </label>
            </div>
         )}

         <textarea 
            className="w-full h-64 p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl font-mono text-xs outline-none focus:ring-2 focus:ring-primary/50 resize-none"
            placeholder={mode === 'encode' ? 'Base64 output will appear here...' : 'Paste Base64 string here to decode...'}
            value={input}
            onChange={(e) => setInput(e.target.value)}
         ></textarea>

         <div className="flex gap-4 mt-4">
            <button onClick={copy} className="flex-1 py-3 bg-slate-200 dark:bg-slate-800 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors">
               <Copy size={18} /> Copy
            </button>
            {mode === 'decode' && (
               <button onClick={downloadDecode} className="flex-1 py-3 bg-primary text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-600 transition-colors">
                  <Download size={18} /> Download as File
               </button>
            )}
         </div>
      </div>
    </div>
  );
};

export default Base64Converter;
