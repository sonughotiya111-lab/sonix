import React, { useContext, useState, useEffect, useRef } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { 
  Menu, Moon, Sun, Search, ChevronRight, LayoutGrid, Zap, 
  X, ScanLine, QrCode, User, Heart, Send, Settings as SettingsIcon, LogOut, Award,
  Wrench, Sparkles, Crown, Check, Tag, Star
} from 'lucide-react';
import { TOOLS } from '../constants';
import { ThemeContext } from '../App';
import { Tool } from '../types';
import { useToast } from './ToastContext';
import { usePremium } from './PremiumContext';
import SonixLogo from './SonixLogo';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { theme, toggleTheme, settings, updateSettings } = useContext(ThemeContext);
  const { isPremium, usageCount, incrementUsage, redeemCoupon, daysLeft, maxFreeUses } = usePremium();
  const { showToast } = useToast();
  const location = useLocation();
  const navigate = useNavigate();
  
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Group tools by category
  const toolsByCategory = TOOLS.reduce((acc, tool) => {
    if (!acc[tool.category]) acc[tool.category] = [];
    acc[tool.category].push(tool);
    return acc;
  }, {} as Record<string, Tool[]>);

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
        setTimeout(() => searchInputRef.current?.focus(), 100);
      }
      if (e.ctrlKey && e.key === 'g') {
        e.preventDefault();
        navigate('/tools/qr-generator');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [navigate]);

  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = redeemCoupon(couponCode);
    if (result.success) {
      showToast(result.message, "success");
      setCouponCode('');
    } else {
      showToast(result.message, "error");
    }
  };

  const handleToolClick = (e: React.MouseEvent, path: string) => {
    if (path === '/') return;
    if (path === location.pathname) return;

    const allowed = incrementUsage();
    if (!allowed) {
      e.preventDefault();
      // Instead of modal, redirect to plan selection page
      navigate('/plans');
      showToast("Free limit reached. Upgrade to continue.", "error");
    }
  };

  const openProfile = () => {
    setIsProfileOpen(true);
  };

  // Premium UI Classes
  const sidebarClass = isPremium 
    ? "bg-slate-900/95 border-r border-amber-500/30 shadow-[4px_0_24px_-12px_rgba(245,158,11,0.2)]"
    : "bg-white/50 dark:bg-slate-900/50 border-r border-slate-200 dark:border-slate-800";
    
  return (
    <div className={`flex h-screen overflow-hidden transition-colors duration-500 ${isPremium ? 'bg-slate-950' : 'bg-slate-50 dark:bg-slate-950'}`}>
      {/* Desktop Sidebar */}
      <aside 
        className={`${isSidebarOpen ? 'w-64' : 'w-20'} hidden md:flex flex-col backdrop-blur-xl transition-all duration-300 z-20 ${sidebarClass}`}
      >
        <div className={`h-20 flex items-center justify-between px-4 border-b ${isPremium ? 'border-amber-500/20' : 'border-slate-200 dark:border-slate-800'}`}>
          <div className={`flex items-center gap-3 ${!isSidebarOpen && 'justify-center w-full'}`}>
            <SonixLogo size={isSidebarOpen ? 40 : 32} />
            {isSidebarOpen && (
              <span className={`font-black text-2xl tracking-tight bg-clip-text text-transparent ${isPremium ? 'bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-500 drop-shadow-sm' : 'bg-gradient-to-r from-indigo-500 to-purple-600'}`}>
                {isPremium ? 'SONIX PRO' : 'Sonix'}
              </span>
            )}
          </div>
          {isSidebarOpen && (
            <button onClick={() => setIsSidebarOpen(false)} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-md transition-colors text-slate-500 dark:text-slate-400">
              <Menu size={18} />
            </button>
          )}
        </div>
        
        {!isSidebarOpen && (
           <button onClick={() => setIsSidebarOpen(true)} className="mx-auto mt-4 p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-md text-slate-500 dark:text-slate-400">
             <ChevronRight size={20} />
           </button>
        )}

        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-6">
          {Object.entries(toolsByCategory).map(([category, tools]) => (
            <div key={category}>
               {isSidebarOpen && (
                 <h3 className={`px-3 text-xs font-bold uppercase tracking-wider mb-2 ${isPremium ? 'text-amber-500/60' : 'text-slate-400'}`}>
                   {category}
                 </h3>
               )}
               <div className="space-y-1">
                 {tools.map((tool) => (
                   <NavLink
                     key={tool.id}
                     to={tool.path}
                     onClick={(e) => handleToolClick(e, tool.path)}
                     className={({ isActive }) => `
                       flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group relative
                       ${isActive 
                         ? (isPremium ? 'bg-gradient-to-r from-amber-500/20 to-yellow-600/10 text-amber-400 font-bold shadow-sm border border-amber-500/20' : 'bg-primary/10 text-primary dark:text-primary font-medium shadow-sm')
                         : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-100'}
                     `}
                     title={!isSidebarOpen ? tool.name : ''}
                   >
                     {({ isActive }) => (
                       <>
                         <tool.icon size={20} className={isActive ? (isPremium ? 'text-amber-400' : 'text-primary') : 'group-hover:scale-110 transition-transform'} />
                         {isSidebarOpen && <span className="text-sm">{tool.name}</span>}
                         {isSidebarOpen && (
                           isPremium ? (
                             <span className="ml-auto text-[9px] font-black px-1.5 py-0.5 rounded bg-gradient-to-r from-amber-400 to-yellow-500 text-black shadow-[0_0_8px_rgba(251,191,36,0.5)]">PRO</span>
                           ) : (
                             tool.isNew && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_8px_#22c55e]"></span>
                           )
                         )}
                       </>
                     )}
                   </NavLink>
                 ))}
               </div>
            </div>
          ))}
        </nav>
        
        {/* User Profile Sidebar Button */}
        <div className={`p-4 border-t ${isPremium ? 'border-amber-500/20' : 'border-slate-200 dark:border-slate-800'}`}>
           <button onClick={openProfile} className={`w-full flex items-center ${isSidebarOpen ? 'justify-start gap-3' : 'justify-center'} p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-400 group`}>
             <div className={`w-8 h-8 rounded-full p-[2px] ${isPremium ? 'bg-gradient-to-tr from-amber-300 via-yellow-400 to-amber-600 animate-pulse-slow' : 'bg-gradient-to-tr from-indigo-500 to-purple-500'}`}>
                <div className={`w-full h-full rounded-full flex items-center justify-center ${isPremium ? 'bg-slate-900' : 'bg-white dark:bg-slate-900'}`}>
                   {isPremium ? <Crown size={14} className="text-amber-400" fill="currentColor" /> : <User size={14} className="text-primary" />}
                </div>
             </div>
             {isSidebarOpen && (
               <div className="flex flex-col items-start">
                 <span className={`text-sm font-bold ${isPremium ? 'text-amber-400' : 'text-slate-800 dark:text-slate-200'}`}>
                    {isPremium ? 'Premium User' : 'Guest User'}
                 </span>
                 <span className="text-[10px] text-slate-400">
                    Menu
                 </span>
               </div>
             )}
           </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Header */}
        <header className={`h-14 md:h-16 flex items-center justify-between px-4 md:px-8 border-b z-[40] sticky top-0 transition-all backdrop-blur-xl ${isPremium ? 'bg-slate-950/80 border-amber-900/30 shadow-[0_4px_30px_-10px_rgba(245,158,11,0.1)]' : 'bg-white/70 dark:bg-slate-900/70 border-slate-200 dark:border-slate-800'}`}>
           
           {/* Mobile Logo */}
           <div className="md:hidden flex items-center">
              <div className={`relative flex items-center gap-2 px-4 py-1.5 rounded-lg shadow-[0_0_15px_rgba(251,191,36,0.4)] border ${isPremium ? 'bg-gradient-to-r from-amber-900 to-black border-amber-500/50' : 'bg-gradient-to-r from-yellow-700 via-amber-600 to-yellow-800 border-yellow-600/30'}`}>
                  <Wrench size={18} className="text-white animate-wiggle drop-shadow-md" />
                  <h1 className="text-lg font-black italic tracking-wider text-white drop-shadow-[0_2px_2px_rgba(0,0,0,0.5)] flex items-center gap-1">
                     SONIX <span className={`text-[10px] font-bold opacity-90 not-italic tracking-normal px-1 rounded ${isPremium ? 'bg-amber-400 text-black' : 'bg-black/20 text-white'}`}>{isPremium ? 'PRO' : 'TOOLS'}</span>
                  </h1>
                  <Sparkles size={14} className="absolute -top-1 -right-1 text-yellow-200 animate-pulse" />
              </div>
           </div>

           {/* Desktop Search */}
           <div className="hidden md:flex flex-1 max-w-md ml-4">
             <div className="relative w-full group">
               <Search className={`absolute left-3 top-1/2 -translate-y-1/2 transition-colors ${isPremium ? 'text-amber-700 group-focus-within:text-amber-500' : 'text-slate-400 group-focus-within:text-primary'}`} size={18} />
               <input 
                 ref={searchInputRef}
                 type="text" 
                 placeholder="Search tools (Ctrl+K)..." 
                 className={`w-full pl-10 pr-4 py-2.5 rounded-2xl text-sm outline-none transition-all ${isPremium ? 'bg-slate-900 border border-amber-900/40 focus:ring-2 focus:ring-amber-500/30 text-amber-100 placeholder:text-amber-900/50' : 'bg-slate-100 dark:bg-slate-800/50 border-none focus:ring-2 focus:ring-primary/50'}`}
               />
             </div>
           </div>

           <div className="flex items-center gap-3">
             {/* Premium Badge Desktop */}
             {!isPremium && (
                <button onClick={() => navigate('/plans')} className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-black text-xs font-bold rounded-lg shadow-lg shadow-amber-500/20 hover:scale-105 transition-transform animate-pulse-slow">
                   <Crown size={14} fill="black" /> GO PRO
                </button>
             )}
             
             {/* Mobile Profile Icon */}
             <button onClick={openProfile} className={`md:hidden w-8 h-8 rounded-full flex items-center justify-center border shadow-sm active:scale-95 transition-transform ${isPremium ? 'bg-amber-900/20 border-amber-500/50 text-amber-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 border-slate-200 dark:border-slate-700'}`}>
               {isPremium ? <Crown size={16} fill="currentColor" /> : <User size={16} />}
             </button>
           </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 md:p-8 scroll-smooth" id="main-scroll">
          <div className="max-w-6xl mx-auto pb-36 md:pb-8">
             {children}
          </div>
        </div>

        {/* Floating Mobile Nav */}
        <div className="md:hidden fixed bottom-6 left-6 right-6 z-50">
          <div className={`h-16 rounded-[2rem] shadow-2xl flex items-center justify-between px-2 relative backdrop-blur-2xl ${isPremium ? 'bg-slate-900/90 border border-amber-500/40 shadow-amber-900/20' : 'glass-panel shadow-indigo-500/10 border border-white/40 dark:border-slate-700/60'}`}>
            
            {/* Left */}
            <div className="flex items-center gap-1 w-1/3 justify-around">
               <NavLink to="/" className={({isActive}) => `flex flex-col items-center justify-center w-12 h-12 rounded-2xl transition-all duration-300 ${isActive ? (isPremium ? 'text-amber-400' : 'text-primary') : 'text-slate-400 hover:text-slate-600'}`}>
                  {({ isActive }) => (
                    <>
                      <LayoutGrid size={22} strokeWidth={isActive ? 2.5 : 2} className={`transition-transform ${isActive ? '-translate-y-1' : ''}`} />
                      {isActive && <div className={`w-1 h-1 rounded-full mt-1 animate-fade-in ${isPremium ? 'bg-amber-400' : 'bg-primary'}`}></div>}
                    </>
                  )}
               </NavLink>
               <NavLink to="/plans" className={({isActive}) => `flex flex-col items-center justify-center w-12 h-12 rounded-2xl transition-all duration-300 ${isActive ? (isPremium ? 'text-amber-400' : 'text-primary') : 'text-slate-400 hover:text-slate-600'}`}>
                  {({ isActive }) => (
                     <>
                        <Zap size={22} strokeWidth={isActive ? 2.5 : 2} className={`transition-transform ${isActive ? '-translate-y-1' : ''}`} />
                        {isActive && <div className={`w-1 h-1 rounded-full mt-1 animate-fade-in ${isPremium ? 'bg-amber-400' : 'bg-primary'}`}></div>}
                     </>
                  )}
               </NavLink>
            </div>

            {/* FAB */}
            <div className="absolute left-1/2 -top-6 -translate-x-1/2">
              <NavLink 
                to="/tools/qr-reader"
                onClick={(e) => handleToolClick(e, '/tools/qr-reader')}
                className={({isActive}) => `
                  group relative flex items-center justify-center w-16 h-16 rounded-full text-white shadow-2xl transition-transform duration-300
                  ${isActive ? 'scale-110' : 'hover:scale-105 active:scale-95'}
                `}
              >
                {({ isActive }) => (
                  <>
                    <div className={`absolute inset-0 rounded-full blur-lg opacity-60 ${isActive ? 'animate-pulse-slow' : ''} ${isPremium ? 'bg-gradient-to-tr from-amber-500 to-yellow-600' : 'bg-gradient-to-tr from-indigo-500 to-purple-600'}`}></div>
                    <div className="absolute inset-[-4px] rounded-full border-2 border-transparent border-t-white/50 border-l-white/50 opacity-80 animate-spin-slow"></div>
                    <div className={`relative w-full h-full rounded-full border-4 border-slate-50 dark:border-slate-900 flex items-center justify-center z-10 shadow-inner ${isPremium ? 'bg-gradient-to-br from-amber-600 to-yellow-700' : 'bg-gradient-to-br from-indigo-600 to-purple-700'}`}>
                      <ScanLine size={24} className={isActive ? 'animate-none' : 'group-hover:rotate-90 transition-transform duration-500'} />
                    </div>
                  </>
                )}
              </NavLink>
            </div>

            {/* Right */}
            <div className="flex items-center gap-1 w-1/3 justify-around">
               <NavLink to="/tools/qr-generator" onClick={(e) => handleToolClick(e, '/tools/qr-generator')} className={({isActive}) => `flex flex-col items-center justify-center w-12 h-12 rounded-2xl transition-all duration-300 ${isActive ? (isPremium ? 'text-amber-400' : 'text-primary') : 'text-slate-400 hover:text-slate-600'}`}>
                  {({ isActive }) => (
                     <>
                        <QrCode size={22} strokeWidth={isActive ? 2.5 : 2} className={`transition-transform ${isActive ? '-translate-y-1' : ''}`} />
                        {isActive && <div className={`w-1 h-1 rounded-full mt-1 animate-fade-in ${isPremium ? 'bg-amber-400' : 'bg-primary'}`}></div>}
                     </>
                  )}
               </NavLink>
               
               <button 
                  onClick={openProfile} 
                  className={`flex flex-col items-center justify-center w-12 h-12 rounded-2xl text-slate-400 hover:text-slate-600 transition-colors ${isProfileOpen ? (isPremium ? 'text-amber-400' : 'text-primary') : ''}`}
                >
                  <SettingsIcon size={22} strokeWidth={isProfileOpen ? 2.5 : 2} />
               </button>
            </div>

          </div>
        </div>
      </main>

      {/* Simplified Profile Modal */}
      {isProfileOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
           <div className={`bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl border flex flex-col max-h-[85vh] animate-slide-up ${isPremium ? 'border-amber-500/30' : 'border-slate-200 dark:border-slate-800'}`}>
              
              {/* Header */}
              <div className={`p-6 text-white text-center relative ${isPremium ? 'bg-gradient-to-br from-amber-600 to-yellow-600' : 'bg-gradient-to-br from-indigo-600 to-purple-700'}`}>
                  <button onClick={() => setIsProfileOpen(false)} className="absolute top-4 right-4 p-2 bg-white/20 hover:bg-white/30 rounded-full transition-colors">
                      <X size={16} />
                  </button>
                  <div className="w-16 h-16 rounded-full bg-white mx-auto mb-3 flex items-center justify-center shadow-lg">
                      {isPremium ? <Crown size={30} className="text-amber-500" fill="currentColor" /> : <User size={30} className="text-primary" />}
                  </div>
                  <h2 className="text-xl font-bold">{isPremium ? 'Premium User' : 'Guest User'}</h2>
                  <p className="text-sm opacity-90">{isPremium ? 'Sonix Pro Active' : `${maxFreeUses - usageCount} free uses left`}</p>
              </div>

              {/* Scrollable List Content */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  
                  {/* Subscription Section */}
                  <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                      <div className="flex justify-between items-center mb-2">
                          <span className="text-xs font-bold text-slate-500 uppercase">Subscription</span>
                          {isPremium ? (
                             <span className="text-xs bg-amber-500/20 text-amber-500 px-2 py-0.5 rounded font-bold">PRO</span>
                          ) : (
                             <span className="text-xs bg-slate-200 text-slate-500 px-2 py-0.5 rounded font-bold">FREE</span>
                          )}
                      </div>
                      
                      {!isPremium && (
                        <div className="mb-3">
                           <div className="flex justify-between text-xs text-slate-500 mb-1">
                              <span>Daily Limit</span>
                              <span>{usageCount}/{maxFreeUses} used</span>
                           </div>
                           <div className="h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                              <div className="h-full bg-primary" style={{ width: `${(usageCount/maxFreeUses)*100}%` }}></div>
                           </div>
                        </div>
                      )}

                      {!isPremium && (
                          <button onClick={() => { setIsProfileOpen(false); navigate('/plans'); }} className="w-full py-2 bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-bold text-sm rounded-lg shadow-sm">
                              Upgrade to Premium
                          </button>
                      )}

                      {/* Coupon Field */}
                      <form onSubmit={handleCouponSubmit} className="mt-3 flex gap-2">
                          <input 
                             type="text" 
                             placeholder="Promo Code" 
                             className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 text-sm"
                             value={couponCode}
                             onChange={(e) => setCouponCode(e.target.value)}
                          />
                          <button type="submit" className="bg-slate-200 dark:bg-slate-700 px-3 py-1.5 rounded-lg text-xs font-bold">Apply</button>
                      </form>
                  </div>

                  {/* App Settings */}
                  <div className="space-y-2">
                      <p className="text-xs font-bold text-slate-500 uppercase ml-1">App Settings</p>
                      
                      <button onClick={toggleTheme} className="w-full flex items-center justify-between p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                          <div className="flex items-center gap-3">
                              {theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
                              <span className="text-sm font-medium">Theme</span>
                          </div>
                          <span className="text-xs font-bold capitalize text-slate-500">{theme}</span>
                      </button>

                      <div className="w-full flex items-center justify-between p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                          <div className="flex items-center gap-3">
                              <Zap size={18} />
                              <span className="text-sm font-medium">Reduced Motion</span>
                          </div>
                          <input type="checkbox" checked={settings.reducedMotion} onChange={(e) => updateSettings({ reducedMotion: e.target.checked })} className="accent-primary" />
                      </div>
                  </div>

                  {/* Reset */}
                  <button onClick={() => { localStorage.clear(); window.location.reload(); }} className="w-full py-3 text-red-500 text-sm font-medium hover:bg-red-50 dark:hover:bg-red-900/10 rounded-xl transition-colors flex items-center justify-center gap-2">
                      <LogOut size={16} /> Reset App Data
                  </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Layout;