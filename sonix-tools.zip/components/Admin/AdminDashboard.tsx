import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, RefreshCcw, CheckCircle, XCircle, Search, DollarSign } from 'lucide-react';
import { usePremium } from '../PremiumContext';
import { useToast } from '../ToastContext';

// Mock Data Type
interface PaymentRequest {
  id: string;
  user: string;
  amount: string;
  utr: string;
  date: string;
  status: 'pending' | 'approved' | 'rejected';
}

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { mockAdminData, adminApprovePayment } = usePremium();
  const [requests, setRequests] = useState<PaymentRequest[]>([]);
  const [filter, setFilter] = useState('pending');

  useEffect(() => {
    // Check auth
    const isAuth = localStorage.getItem('sonix_admin_auth');
    if (!isAuth) {
      navigate('/admin');
      return;
    }
    // Load mock data from context
    setRequests(mockAdminData);
  }, [mockAdminData, navigate]);

  const handleLogout = () => {
    localStorage.removeItem('sonix_admin_auth');
    navigate('/admin');
  };

  const handleApprove = (id: string) => {
    adminApprovePayment(id); // This updates the context state
    showToast(`Payment ${id} Approved`, 'success');
  };

  const handleReject = (id: string) => {
    // Logic to reject (in real app, updates DB)
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'rejected' } : r));
    showToast(`Payment ${id} Rejected`, 'error');
  };

  const filteredRequests = requests.filter(r => r.status === filter);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans">
      {/* Navbar */}
      <nav className="h-16 border-b border-slate-800 bg-slate-900/50 backdrop-blur-md flex items-center justify-between px-6 sticky top-0 z-20">
        <div className="flex items-center gap-2">
           <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-black italic text-white text-sm">A</div>
           <span className="font-bold text-lg">Admin Control</span>
        </div>
        <button onClick={handleLogout} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors">
           <LogOut size={20} />
        </button>
      </nav>

      <div className="max-w-6xl mx-auto p-6 md:p-8">
         {/* Stats */}
         <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
               <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Pending Revenue</p>
               <h3 className="text-3xl font-black text-white">₹{requests.filter(r=>r.status === 'pending').reduce((acc, curr) => acc + parseInt(curr.amount), 0)}</h3>
            </div>
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
               <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Pending Requests</p>
               <h3 className="text-3xl font-black text-amber-500">{requests.filter(r=>r.status === 'pending').length}</h3>
            </div>
            <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
               <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Total Users</p>
               <h3 className="text-3xl font-black text-indigo-500">1,204</h3>
            </div>
         </div>

         {/* Filters */}
         <div className="flex items-center gap-4 mb-6 overflow-x-auto pb-2">
            {['pending', 'approved', 'rejected'].map(f => (
               <button 
                 key={f}
                 onClick={() => setFilter(f)}
                 className={`px-4 py-2 rounded-full text-sm font-bold capitalize transition-colors ${filter === f ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-500 hover:text-slate-300'}`}
               >
                 {f}
               </button>
            ))}
            <div className="ml-auto relative hidden md:block">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" size={14} />
               <input type="text" placeholder="Search UTR..." className="bg-slate-900 border border-slate-800 rounded-full py-2 pl-9 pr-4 text-sm outline-none focus:border-indigo-500" />
            </div>
         </div>

         {/* Table List */}
         <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
               <table className="w-full text-left border-collapse">
                  <thead>
                     <tr className="bg-slate-950/50 border-b border-slate-800 text-slate-500 text-xs uppercase tracking-wider">
                        <th className="p-4 font-semibold">User / ID</th>
                        <th className="p-4 font-semibold">UTR Number</th>
                        <th className="p-4 font-semibold">Date</th>
                        <th className="p-4 font-semibold">Amount</th>
                        <th className="p-4 font-semibold text-right">Actions</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                     {filteredRequests.length === 0 ? (
                        <tr>
                           <td colSpan={5} className="p-8 text-center text-slate-500">No {filter} requests found.</td>
                        </tr>
                     ) : (
                        filteredRequests.map((req) => (
                           <tr key={req.id} className="hover:bg-slate-800/50 transition-colors">
                              <td className="p-4">
                                 <div className="font-bold text-white">{req.user}</div>
                                 <div className="text-xs text-slate-500 font-mono">ID: {req.id}</div>
                              </td>
                              <td className="p-4 font-mono text-indigo-400">{req.utr}</td>
                              <td className="p-4 text-slate-400 text-sm">{req.date}</td>
                              <td className="p-4 font-bold text-white">₹{req.amount}</td>
                              <td className="p-4 text-right">
                                 {req.status === 'pending' ? (
                                    <div className="flex items-center justify-end gap-2">
                                       <button onClick={() => handleApprove(req.id)} className="p-2 bg-green-500/10 text-green-500 hover:bg-green-500 hover:text-white rounded-lg transition-colors" title="Approve">
                                          <CheckCircle size={18} />
                                       </button>
                                       <button onClick={() => handleReject(req.id)} className="p-2 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded-lg transition-colors" title="Reject">
                                          <XCircle size={18} />
                                       </button>
                                    </div>
                                 ) : (
                                    <span className={`text-xs font-bold px-2 py-1 rounded border ${req.status === 'approved' ? 'border-green-500/30 text-green-500' : 'border-red-500/30 text-red-500'}`}>
                                       {req.status.toUpperCase()}
                                    </span>
                                 )}
                              </td>
                           </tr>
                        ))
                     )}
                  </tbody>
               </table>
            </div>
         </div>
      </div>
    </div>
  );
};

export default AdminDashboard;