import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Lock, ChevronRight } from 'lucide-react';
import { useToast } from '../ToastContext';

const AdminLogin: React.FC = () => {
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const { showToast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // HARDCODED PASSWORD FOR DEMO
    if (password === 'admin123') {
      localStorage.setItem('sonix_admin_auth', 'true');
      showToast('Welcome back, Admin', 'success');
      navigate('/admin/dashboard');
    } else {
      showToast('Access Denied', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 relative overflow-hidden">
       {/* Background Effects */}
       <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-blue-900/20 to-transparent"></div>
       <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-600/10 blur-[100px] rounded-full"></div>

       <div className="w-full max-w-md bg-slate-900/80 backdrop-blur-xl border border-slate-800 p-8 rounded-3xl shadow-2xl relative z-10 animate-slide-up">
          <div className="flex justify-center mb-8">
             <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/30">
                <ShieldCheck size={40} className="text-white" />
             </div>
          </div>

          <h1 className="text-2xl font-black text-center text-white mb-2">Admin Portal</h1>
          <p className="text-slate-400 text-center text-sm mb-8">Authorize to manage payments</p>

          <form onSubmit={handleLogin} className="space-y-6">
             <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Access Key</label>
                <div className="relative">
                   <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                   <input 
                     type="password" 
                     value={password}
                     onChange={(e) => setPassword(e.target.value)}
                     className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3.5 pl-12 pr-4 text-white placeholder:text-slate-600 focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all"
                     placeholder="Enter security code..."
                   />
                </div>
             </div>

             <button type="submit" className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-900/20 transition-all flex items-center justify-center gap-2 group">
                Access Dashboard <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
             </button>
          </form>

          <button onClick={() => navigate('/')} className="w-full mt-6 text-slate-600 hover:text-slate-400 text-sm font-medium transition-colors">
             Return to App
          </button>
       </div>
    </div>
  );
};

export default AdminLogin;