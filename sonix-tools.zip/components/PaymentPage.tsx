import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ScanLine, ArrowLeft, CheckCircle, Copy, AlertCircle } from 'lucide-react';
import { usePremium } from './PremiumContext';
import { useToast } from './ToastContext';

const PaymentPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { submitPayment, isPremium } = usePremium();
  const { showToast } = useToast();
  
  const initialAmount = searchParams.get('amount') || '';
  const [amount, setAmount] = useState(initialAmount);
  const [utr, setUtr] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (initialAmount) {
        setAmount(initialAmount);
    }
  }, [initialAmount]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !utr) {
        showToast("Please fill in all details", "error");
        return;
    }
    submitPayment(amount, utr);
    setSubmitted(true);
    showToast("Payment submitted for verification", "success");
  };

  const copyUpi = () => {
    navigator.clipboard.writeText('sonughotiya12345-1@okhdfcbank');
    showToast("UPI ID Copied");
  };

  if (isPremium) {
      return (
          <div className="p-8 flex flex-col items-center justify-center min-h-[50vh] text-center">
              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center text-white mb-4 shadow-lg shadow-green-500/30">
                  <CheckCircle size={40} />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">You are already Premium!</h2>
              <button onClick={() => navigate('/')} className="mt-4 px-6 py-2 bg-slate-800 text-white rounded-xl">Go Home</button>
          </div>
      );
  }

  if (submitted) {
      return (
          <div className="p-8 flex flex-col items-center justify-center min-h-[60vh] text-center animate-fade-in">
              <div className="w-24 h-24 bg-amber-500/20 rounded-full flex items-center justify-center text-amber-500 mb-6 border border-amber-500/50">
                  <ScanLine size={40} className="animate-pulse" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">Verification Pending</h2>
              <p className="text-slate-400 mb-8 max-w-sm">
                  We have received your payment details (Amount: ₹{amount}, UTR: {utr}). <br/>
                  Admin will verify and activate your Premium plan shortly.
              </p>
              <button 
                onClick={() => navigate('/')} 
                className="px-8 py-3 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-bold rounded-xl shadow-lg"
              >
                  Back to Dashboard
              </button>
          </div>
      );
  }

  // Generate dynamic QR URL based on amount
  // am=AMOUNT param in UPI link sets the pre-filled amount
  const qrData = `upi://pay?pa=sonughotiya12345-1@okhdfcbank&pn=SonixTools&cu=INR${amount ? `&am=${amount}` : ''}`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrData)}`;

  return (
    <div className="max-w-xl mx-auto animate-slide-up pb-10">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors">
         <ArrowLeft size={20} /> Back
      </button>

      <div className="bg-slate-900 border border-amber-500/30 rounded-3xl overflow-hidden shadow-2xl">
         {/* Header */}
         <div className="bg-gradient-to-r from-amber-600 to-yellow-600 p-6 text-black text-center">
            <h1 className="text-2xl font-black italic tracking-wider">SECURE PAYMENT</h1>
            <p className="font-medium opacity-80">Pay to Activate Premium</p>
         </div>

         <div className="p-6 md:p-8 space-y-8">
            
            {/* Step 1: QR */}
            <div className="space-y-4">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-amber-500 font-bold uppercase text-xs tracking-widest">
                        <span className="w-6 h-6 rounded-full bg-amber-500 text-black flex items-center justify-center text-[10px]">1</span>
                        Scan & Pay
                    </div>
                    {amount && <div className="text-white font-bold text-lg">Amount: ₹{amount}</div>}
                </div>
                
                <div className="bg-white p-4 rounded-2xl flex flex-col items-center shadow-inner">
                    <img 
                        src={qrUrl}
                        alt="UPI QR" 
                        className="w-56 h-56 mix-blend-multiply"
                    />
                    <div onClick={copyUpi} className="mt-3 flex items-center gap-2 text-xs font-mono bg-slate-100 px-3 py-1.5 rounded cursor-pointer active:scale-95 transition-transform text-slate-800">
                        sonughotiya12345-1@okhdfcbank <Copy size={12} />
                    </div>
                </div>

                {!initialAmount && (
                    <div className="grid grid-cols-3 gap-2">
                        {[25, 100, 200].map(amt => (
                            <button key={amt} onClick={() => setAmount(amt.toString())} className="py-2 border border-slate-700 hover:border-amber-500 rounded-lg text-slate-300 hover:text-amber-500 transition-colors text-sm font-bold">
                                ₹{amt}
                            </button>
                        ))}
                    </div>
                )}
            </div>

            <div className="h-px bg-slate-800"></div>

            {/* Step 2: Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex items-center gap-2 text-amber-500 font-bold uppercase text-xs tracking-widest">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-black flex items-center justify-center text-[10px]">2</span>
                    Verify Payment
                </div>
                
                <div className="space-y-3">
                    <div>
                        <label className="block text-xs font-semibold text-slate-400 mb-1">Amount Paid (₹)</label>
                        <input 
                            type="number" 
                            required
                            readOnly={!!initialAmount}
                            placeholder="e.g. 200"
                            value={amount}
                            onChange={e => setAmount(e.target.value)}
                            className={`w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-amber-500/50 outline-none ${initialAmount ? 'opacity-70 cursor-not-allowed' : ''}`}
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-semibold text-slate-400 mb-1">UTR / Transaction ID</label>
                        <input 
                            type="text" 
                            required
                            placeholder="e.g. 40591834..."
                            value={utr}
                            onChange={e => setUtr(e.target.value)}
                            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-amber-500/50 outline-none"
                        />
                    </div>
                </div>

                <div className="pt-4">
                    <button type="submit" className="w-full py-4 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-bold text-lg rounded-xl shadow-lg shadow-amber-900/20 transition-all active:scale-[0.98]">
                        Submit for Verification
                    </button>
                    <p className="text-[10px] text-center text-slate-500 mt-3 flex items-center justify-center gap-1">
                        <AlertCircle size={10} /> Admin will verify manually
                    </p>
                </div>
            </form>
         </div>
      </div>
    </div>
  );
};

export default PaymentPage;