import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

const SonixLogo: React.FC<LogoProps> = ({ className = "", size = 40 }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    className={`${className} drop-shadow-lg`}
  >
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="100%" x2="100%" y2="0%">
        <stop offset="0%" style={{ stopColor: '#6366f1', stopOpacity: 1 }} />
        <stop offset="50%" style={{ stopColor: '#8b5cf6', stopOpacity: 1 }} />
        <stop offset="100%" style={{ stopColor: '#ec4899', stopOpacity: 1 }} />
      </linearGradient>
      <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
        <feGaussianBlur stdDeviation="8" result="blur" />
        <feComposite in="SourceGraphic" in2="blur" operator="over" />
      </filter>
    </defs>
    
    {/* Outer Glow Circle (Subtle) */}
    <circle cx="50" cy="50" r="45" fill="url(#logoGradient)" fillOpacity="0.1" />
    
    {/* The S Wave Shape */}
    <path 
      d="M68 32C68 25.3726 62.6274 20 56 20H44C30.7452 20 20 30.7452 20 44C20 57.2548 30.7452 68 44 68H56C62.6274 68 68 73.3726 68 80C68 86.6274 62.6274 92 56 92H32" 
      stroke="url(#logoGradient)" 
      strokeWidth="12" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
    />
    
    {/* Decorative Dot */}
    <circle cx="78" cy="20" r="6" fill="#ec4899" className="animate-pulse" />
  </svg>
);

export default SonixLogo;