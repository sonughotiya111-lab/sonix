import React, { createContext, useContext, useEffect, useCallback, useState } from 'react';
import { PremiumContextType } from '../types';
import { ThemeContext } from '../App';
import { useToast } from './ToastContext';

// Extended type for internal admin usage
interface AdminContextType extends PremiumContextType {
  mockAdminData: any[];
  adminApprovePayment: (id: string) => void;
}

export const PremiumContext = createContext<AdminContextType | undefined>(undefined);

const MAX_FREE_USES = 5;

// MOCK DATA STORAGE (In real app, this is Firebase)
const INITIAL_MOCK_REQUESTS = [
  { id: 'PAY_001', user: 'User_9921', amount: '200', utr: '88391029381', date: '2023-10-25', status: 'pending' },
  { id: 'PAY_002', user: 'User_1102', amount: '100', utr: '99281726351', date: '2023-10-24', status: 'approved' },
];

export const PremiumProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { settings, updateSettings } = useContext(ThemeContext);
  const { showToast } = useToast();
  
  // Local state to simulate database for Admin view
  const [mockRequests, setMockRequests] = useState(INITIAL_MOCK_REQUESTS);

  // Check expiry on load
  useEffect(() => {
    if (settings.subscription.isPremium && settings.subscription.expiry) {
      if (Date.now() > settings.subscription.expiry) {
        // Expired
        updateSettings({
          subscription: {
            ...settings.subscription,
            isPremium: false,
            plan: 'free',
            expiry: null
          }
        });
        showToast("Premium subscription expired.", "error");
      }
    }
  }, [settings.subscription.isPremium, settings.subscription.expiry, updateSettings, showToast]);

  const incrementUsage = useCallback(() => {
    if (settings.subscription.isPremium) return true;
    
    // Free limit
    if (settings.usageCount >= MAX_FREE_USES) {
      return false;
    }
    
    updateSettings({ usageCount: (settings.usageCount || 0) + 1 });
    return true;
  }, [settings.subscription.isPremium, settings.usageCount, updateSettings]);

  const activatePlan = (plan: 'monthly' | 'yearly' | 'lifetime' | 'trial', durationDays?: number) => {
    let expiry = null;
    if (durationDays) {
      expiry = Date.now() + (durationDays * 24 * 60 * 60 * 1000);
    } else if (plan === 'monthly') {
      expiry = Date.now() + (30 * 24 * 60 * 60 * 1000);
    } else if (plan === 'yearly') {
      expiry = Date.now() + (365 * 24 * 60 * 60 * 1000);
    }
    // Lifetime has null expiry

    updateSettings({
      subscription: {
        isPremium: true,
        plan,
        expiry,
        trialUsed: plan === 'trial' ? true : settings.subscription.trialUsed,
        paymentPending: false
      },
      usageCount: 0 
    });
  };

  const submitPayment = (amount: string, utr: string) => {
    // 1. Update User State
    updateSettings({
        subscription: {
            ...settings.subscription,
            paymentPending: true
        }
    });

    // 2. Add to Admin Mock DB (Simulation)
    const newReq = {
      id: `PAY_${Math.floor(Math.random() * 1000)}`,
      user: 'Current_User',
      amount,
      utr,
      date: new Date().toISOString().split('T')[0],
      status: 'pending'
    };
    setMockRequests(prev => [newReq, ...prev]);
  };

  const redeemCoupon = (code: string) => {
    const cleanCode = code.toLowerCase().trim();

    if (cleanCode === 'sonufree') {
      if (settings.subscription.trialUsed) {
        return { success: false, message: "Trial already used on this device." };
      }
      activatePlan('trial', 7);
      return { success: true, message: "7-Day Free Trial Activated!" };
    }

    if (cleanCode === 'sonupremium') {
      activatePlan('lifetime');
      return { success: true, message: "Admin Access Granted: Lifetime Premium" };
    }

    return { success: false, message: "Invalid coupon code." };
  };

  // Admin function to approve payment (Simulates accepting a user)
  const adminApprovePayment = (id: string) => {
    setMockRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'approved' } : r));
    
    // In a real app with Firebase, this would update the specific user's document.
    // Here, if we approve the current session's request, we activate it locally.
    const req = mockRequests.find(r => r.id === id);
    if(req && req.user === 'Current_User') {
       activatePlan('lifetime'); // Default to lifetime for manual approval
    }
  };

  const daysLeft = settings.subscription.expiry 
    ? Math.ceil((settings.subscription.expiry - Date.now()) / (1000 * 60 * 60 * 24)) 
    : null;

  return (
    <PremiumContext.Provider value={{
      isPremium: settings.subscription.isPremium,
      usageCount: settings.usageCount,
      maxFreeUses: MAX_FREE_USES,
      incrementUsage,
      activatePlan,
      redeemCoupon,
      submitPayment,
      daysLeft,
      paymentPending: !!settings.subscription.paymentPending,
      mockAdminData: mockRequests,
      adminApprovePayment
    }}>
      {children}
    </PremiumContext.Provider>
  );
};

export const usePremium = () => {
  const context = useContext(PremiumContext);
  if (!context) throw new Error('usePremium must be used within PremiumProvider');
  return context;
};