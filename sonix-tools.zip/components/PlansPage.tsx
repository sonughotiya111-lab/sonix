import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Star, Zap, Crown, ShieldCheck, ArrowLeft } from 'lucide-react';

const PlansPage: React.FC = () => {
  const navigate = useNavigate();

  const handleSelectPlan = (amount: number, planName: string) => {
    navigate(`/payment?amount=${amount}&plan=${planName}`);
  };

  return (
    <div className="max-w-4xl mx-auto animate-slide-up pb-10 px-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-slate-400 hover:text-slate-600 dark:hover:text-white mb-6 transition-colors font-medium text-sm">
         <ArrowLeft size={18} /> Back
      </button>

      <div className="text-center mb-8 space-y-3">
        <h1 className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
          Unlock <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600">Full Power</span>
        </h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm md:text-base max-w-lg mx-auto">
          Choose the perfect plan to remove limits and access premium features forever.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 items-center">
        
        {/* Monthly Plan */}
        <div className="relative group p-0.5 rounded-2xl bg-gradient-to-b from-slate-200 to-slate-100 dark:from-slate-800 dark:to-slate-900 transition-transform hover:-translate-y-1 duration-300">
          <div className="bg-white dark:bg-slate-900 rounded-[0.9rem] p-5 h-full flex flex-col">
            <h3 className="text-lg font-bold text-slate-500 mb-1">Monthly</h3>
            <div className="flex items-baseline gap-1 mb-4">
              <span className="text-3xl font-black text-slate-900 dark:text-white">₹25</span>
              <span className="text-slate-400 text-sm">/mo</span>
            </div>
            <ul className="space-y-2 mb-6 flex-1">
              <li className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
                <Check size={14} className="text-indigo-500" /> Remove Daily Limits
              </li>
              <li className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
                <Check size={14} className="text-indigo-500" /> Access All Tools
              </li>
            </ul>
            <button 
              onClick={() => handleSelectPlan(25, 'monthly')}
              className="w-full py-2.5 rounded-lg border-2 border-slate-200 dark:border-slate-700 font-bold text-sm text-slate-600 dark:text-slate-300 hover:border-indigo-500 hover:text-indigo-500 transition-colors"
            >
              Choose Monthly
            </button>
          </div>
        </div>

        {/* Lifetime Plan (Best Value) */}
        <div className="relative group p-0.5 rounded-2xl bg-gradient-to-b from-amber-300 via-yellow-400 to-amber-600 shadow-xl shadow-amber-500/10 transform md:-translate-y-2 hover:-translate-y-3 transition-all duration-300 z-10">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-amber-500 to-yellow-600 text-black text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-md">
            Best Value
          </div>
          <div className="bg-slate-900 rounded-[0.9rem] p-6 h-full flex flex-col relative overflow-hidden">
             {/* Background shine */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
            
            <div className="flex items-center gap-2 mb-1">
               <Crown size={20} className="text-amber-400 fill-amber-400" />
               <h3 className="text-lg font-bold text-amber-100">Lifetime</h3>
            </div>
            
            <div className="flex items-baseline gap-1 mb-1">
              <span className="text-4xl font-black text-white">₹200</span>
              <span className="text-amber-200/60 line-through text-sm">₹500</span>
            </div>
            <p className="text-[10px] text-amber-500 font-bold mb-5 bg-amber-950/50 inline-block px-2 py-0.5 rounded">One-time payment</p>

            <ul className="space-y-3 mb-6 flex-1">
              <li className="flex items-center gap-2 text-xs text-white font-medium">
                <div className="w-4 h-4 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400"><Check size={10} strokeWidth={3} /></div> 
                <span>Unlimited Access Forever</span>
              </li>
              <li className="flex items-center gap-2 text-xs text-white font-medium">
                <div className="w-4 h-4 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400"><Star size={10} strokeWidth={3} /></div> 
                <span>Premium Golden UI</span>
              </li>
              <li className="flex items-center gap-2 text-xs text-white font-medium">
                <div className="w-4 h-4 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400"><ShieldCheck size={10} strokeWidth={3} /></div> 
                <span>Priority Support</span>
              </li>
              <li className="flex items-center gap-2 text-xs text-white font-medium">
                <div className="w-4 h-4 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400"><Zap size={10} strokeWidth={3} /></div> 
                <span>All Future Tools Free</span>
              </li>
            </ul>
            <button 
              onClick={() => handleSelectPlan(200, 'lifetime')}
              className="w-full py-3 rounded-lg bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black text-sm shadow-lg shadow-amber-500/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
            >
              Get Lifetime Access
            </button>
          </div>
        </div>

        {/* Yearly Plan */}
        <div className="relative group p-0.5 rounded-2xl bg-gradient-to-b from-slate-200 to-slate-100 dark:from-slate-800 dark:to-slate-900 transition-transform hover:-translate-y-1 duration-300">
          <div className="bg-white dark:bg-slate-900 rounded-[0.9rem] p-5 h-full flex flex-col">
            <div className="flex justify-between items-start mb-1">
               <h3 className="text-lg font-bold text-slate-500">Yearly</h3>
               <span className="bg-green-100 text-green-700 text-[9px] font-bold px-1.5 py-0.5 rounded-full">SAVE 66%</span>
            </div>
            <div className="flex items-baseline gap-1 mb-4">
              <span className="text-3xl font-black text-slate-900 dark:text-white">₹100</span>
              <span className="text-slate-400 text-sm">/yr</span>
            </div>
            <ul className="space-y-2 mb-6 flex-1">
              <li className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
                <Check size={14} className="text-indigo-500" /> No Ads or Limits
              </li>
              <li className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
                <Check size={14} className="text-indigo-500" /> Priority Updates
              </li>
              <li className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
                <Check size={14} className="text-indigo-500" /> Cancel Anytime
              </li>
            </ul>
            <button 
              onClick={() => handleSelectPlan(100, 'yearly')}
              className="w-full py-2.5 rounded-lg border-2 border-slate-200 dark:border-slate-700 font-bold text-sm text-slate-600 dark:text-slate-300 hover:border-indigo-500 hover:text-indigo-500 transition-colors"
            >
              Choose Yearly
            </button>
          </div>
        </div>

      </div>
      
      <div className="mt-8 text-center">
         <p className="text-xs text-slate-400">Secure payment via UPI • 100% Money-back guarantee for 7 days</p>
      </div>
    </div>
  );
};

export default PlansPage;